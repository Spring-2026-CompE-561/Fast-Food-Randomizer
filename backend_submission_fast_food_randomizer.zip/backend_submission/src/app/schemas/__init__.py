"""Pydantic request/response schemas."""

